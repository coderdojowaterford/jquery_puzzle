$( document ).ready( function () {
	console.log( "ready!" );
	
	// store the positions of the pieces in an array
	var pieces = {
			0: {id: "piece_1_1", x: 0, y: 0 },
			1: {id: "piece_2_1", x: 1, y: 0 },
			2: {id: "piece_3_1", x: 2, y: 0 },
			3: {id: "piece_1_2", x: 0, y: 1 },
			4: {id: "piece_2_2", x: 1, y: 1 },
			5: {id: "piece_3_2", x: 2, y: 1 },
			6: {id: "piece_1_3", x: 0, y: 2 },
			7: {id: "piece_2_3", x: 1, y: 2 },
	}
	
	// store the position of the empty piece
	var empty_piece = {x: 2, y: 2};

	// this is a function that places a piece in a chosen position
	function place_piece( index, x, y ) {
		pieces[index].x = x;
		pieces[index].y = y;
		$('#' + pieces[index].id).css('left', (x * 33.5) + '%');
		$('#' + pieces[index].id).css('top', (y * 33.5) + '%');
	}	
	
	// try to move a piece if possible
	function move_piece( index ) {
		var current_x = pieces[index].x;
		var current_y = pieces[index].y;
		// move this piece to the empty spot if possible
		if (Math.abs( current_x - empty_piece.x) + Math.abs( current_y - empty_piece.y) == 1 ){
			place_piece( index, empty_piece.x, empty_piece.y );
			empty_piece.x = current_x;
			empty_piece.y = current_y;
		}
	}
	
	// what to do when a piece is clicked
	$('.puzzle-piece').click(function () {
		// find the corresponding piece
		for( var k = 0 ; k < 8 ; k++ ) {
			if ( this.id == pieces[k].id ){
				move_piece( k );
				break;
			}
		}
	});
	
	
	
});
